<div class="adstop">
<!-- LOMADEE - BEGIN -->
<script type="text/javascript" language="javascript">
	lmd_source="25569110";
	lmd_si="33338950";
	lmd_pu="22227150";
	lmd_c="BR";
	lmd_wi="468";
	lmd_he="60";
</script>
<script src="http://image.lomadee.com/js/ad_lomadee.js" type="text/javascript" language="javascript"></script>
<!-- LOMADEE - END -->
</div>