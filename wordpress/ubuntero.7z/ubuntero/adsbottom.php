<div class="adsbottom">
<!-- LOMADEE - BEGIN -->
<script type="text/javascript" language="javascript">
	lmd_source="25569110";
	lmd_si="33338950";
	lmd_pu="22227150";
	lmd_c="BR";
	lmd_wi="468";
	lmd_he="60";
</script>
<script src="http://image.lomadee.com/js/ad_lomadee.js" type="text/javascript" language="javascript"></script>
<!-- LOMADEE - END -->

<?php
/*
$sorteio = rand(1,2);
if ($sorteio == 1){
	_e('
<!-- LOMADEE - BEGIN -->
<script type="text/javascript" language="javascript">
	lmd_source="25569110";
	lmd_si="33338950";
	lmd_pu="22227150";
	lmd_c="BR";
	lmd_wi="468";
	lmd_he="60";
</script>
<script src="http://image.lomadee.com/js/ad_lomadee.js" type="text/javascript" language="javascript"></script>
<!-- LOMADEE - END -->
');
}
elseif ($sorteio == 2){
	_e('<a href="#" target="_blank" rel="nofollow" title="Publicidade"><img src="') . bloginfo('template_directory') . _e('/images/publicidade.jpg" alt="Publicidade 1" /></a>');
}
*/
?>
</div>
